# RigidBodies
A simple DSL for describing rigid bodies and deriving kinematics equations
